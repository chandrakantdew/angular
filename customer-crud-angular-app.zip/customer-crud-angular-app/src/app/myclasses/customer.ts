export class Customer {

    constructor(
        public id="",
        public customerName="",
        public customerContact=0,
        public customerEmail="",
        public username="",
        public password="",
        public registerDate=new Date(),
        public customerImage="Resources/images.png"
    )
    {}


}