import { Component } from '@angular/core';

@Component({
  selector: 'app-databinding',
  templateUrl: './databinding.component.html',
  styleUrl: './databinding.component.css'
})
export class DatabindingComponent {
  companyName = "neosoft";
  setCompanyName(){
    // console.log(this.companyName);
  }

  constructor(){
    setTimeout(()=>{
      this.companyName = "gophygital";
    },5000);
  }

  inputType = "password";
  checkValue = false;

  passwordHandler(){
    // console.log(this.checkValue);
    
    this.checkValue ? this.inputType = "text" : this.inputType = "password";
  }

  getPara(node:HTMLElement){
    console.log(node);
  }

}
