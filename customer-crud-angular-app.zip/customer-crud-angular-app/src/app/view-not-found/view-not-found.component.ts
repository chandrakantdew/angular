import { Component } from '@angular/core';

@Component({
  selector: 'app-view-not-found',
  templateUrl: './view-not-found.component.html',
  styleUrl: './view-not-found.component.css'
})
export class ViewNotFoundComponent {

}
