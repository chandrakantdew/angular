import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NonVegFoodsComponent } from './non-veg-foods.component';

describe('NonVegFoodsComponent', () => {
  let component: NonVegFoodsComponent;
  let fixture: ComponentFixture<NonVegFoodsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [NonVegFoodsComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(NonVegFoodsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
