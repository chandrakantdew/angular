import { Component } from '@angular/core';
import { CounterService } from '../myservices/counter.service';

@Component({
  selector: 'app-non-veg-foods',
  templateUrl: './non-veg-foods.component.html',
  styleUrl: './non-veg-foods.component.css'
})
export class NonVegFoodsComponent {
  counter2 = this.counterService.serviceCounter;
  constructor(private counterService:CounterService){
    console.log(counterService.getCounter());
    
  }

  increment(){
    this.counterService.incrementCounter();
    this.counter2  = this.counterService.getCounter();
  }
}
