import { Component, EventEmitter, Output } from '@angular/core';


@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.css'
})
export class NavbarComponent {
  brandName = "Puma";
  @Output()
  emitter=new EventEmitter<string>();
  ngOnInit(){
    this.emitter.emit(this.brandName);
  }
}
