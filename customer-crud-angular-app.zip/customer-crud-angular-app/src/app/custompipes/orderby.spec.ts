import { Orderby } from './orderby';

describe('Orderby', () => {
  it('should create an instance', () => {
    expect(new Orderby()).toBeTruthy();
  });
});
