import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  loginFlag = false
  constructor() { }

  adminLogin(username:string, password:string):boolean
  {
    if(username=="Admin" && password=="Admin@123")
      this.loginFlag=true
    return this.loginFlag

  }
}
